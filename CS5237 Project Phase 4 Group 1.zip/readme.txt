To compile:

1. In Phase II -> properties -> Linker -> Input, replace the Additional Dependencies with the following:

GL\glut32.lib;%(AdditionalDependencies)

2. Phase II -> Header Files -> Add -> Existing Item -> Add the existing VoronoiDiagramGenerator.h

3. Phase II -> Source Files -> Add -> Existing Item -> Add the existing VoronoiDiagramGenerator.cpp